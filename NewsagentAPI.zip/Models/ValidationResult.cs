﻿namespace AssessmentAPI.Models
{
    public record ValidationResult(bool IsValid, string? Message);
}
