﻿namespace AssessmentAPI.Models
{
    public record ZineCoNewsagent : Newsagent
    {
        public string ChainId { get; init; }
    }
}
